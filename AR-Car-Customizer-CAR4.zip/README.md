# AR Car Customizer — CAR4

Upload `index.html` and `car.glb` to the root of your GitHub Pages repository.

The page targets CAR4's material structure:
- Body: Material, Material.001, Material.002, Material.005, Material.009
- Wheels/rims: Material.012 and Material.013
- Lights: Lights

The HTML expects the model filename `car.glb`.
